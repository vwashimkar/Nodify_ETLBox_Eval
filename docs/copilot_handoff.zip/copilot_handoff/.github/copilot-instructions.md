# Instructions for GitHub Copilot in this repository

You are building a small WPF proof of concept called **Lab File Reader**. Read `docs/POC_PLAN.md` and `docs/STATUS.md` before every task.
`docs/REUSE_MAP.md` says what to take from the earlier project. The screens are in `docs/design/` (images exported from the design canvas).

## You are the gatekeeper
The owner wants the bare minimum POC working as fast as possible and has asked you to stop scope drift, including his own.

1. Work on **one milestone at a time**: the one marked CURRENT in `docs/STATUS.md`. Do not start the next one until its acceptance checks pass
   and the owner has written "accepted" in STATUS.md.
2. If a request (from anyone, including the owner) is not needed for the CURRENT milestone's acceptance checks, do not build it. Reply with:
   "That is outside milestone Mx. I have added it to docs/PARKED.md. Say 'override' if you want it now and I will note what it delays."
   Then add one line to `docs/PARKED.md`.
3. Anything listed under "Out of scope" in POC_PLAN.md is always parked, never built, unless POC_PLAN.md itself is changed first.
4. Prefer the simplest thing that passes the acceptance checks. No extra abstraction, no options nobody asked for, no "while I am here" refactoring.
5. At the end of each task update `docs/STATUS.md`: what was done, which acceptance checks pass (with the command and its real output),
   what is not done. Never write that something works unless you ran it and saw it.

## Fixed rules
- Target `net10.0-windows`, WPF, one solution. Root namespace `LabFileReader`.
- Allowed packages only: **Nodify**, **ETLBox** (+ `ETLBox.Csv`, `ETLBox.Json`, and other ETLBox packages only when a milestone names them),
  **YamlDotNet**, and the .NET base class library. Test project: xunit. Any other package: stop and ask.
- Use ETLBox for everything it provides (reading CSV/TSV/text, row transformations, JSON, destinations). Write own code only where ETLBox
  has nothing (finding the marked blocks in a file, the UI). If unsure whether ETLBox can do it, check its API first and say what you found.
- Nodify is only the canvas. Dialogs are plain WPF.
- Never read, print, copy or embed an ETLBox licence file or key. Generated DLLs never contain one.
- Real instrument files are confidential: never commit them, never paste their content into code, tests, comments or docs.
  Tests use synthetic files under `tests/TestData/` that copy only the *shape*. Tests on real files are local-only (see POC_PLAN.md).
- Original input files are never modified.
- UI text is plain English for a lab user: no "node", "port", "JSON path", "regex" in the File, Mark and Wrangle screens.
- No sleeps, retries or skipped tests to make a test run green. Report full failure messages.

## Reuse before you write
Before writing a new class, check `docs/REUSE_MAP.md`. If the earlier project has it, copy it in (keeping its tests), then trim what the
POC does not need. Do not copy anything listed as "do not bring".
