# Lab File Reader: POC plan

## Goal (one sentence)
A lab user marks the blocks of one instrument file once, wrangles the table through the UI, tests it, and gets a DLL that returns the same
result for the next file from that instrument.

## The flow (screens in docs/design/)
1. **File**: pick or drop one instrument export (text based). Never modified.
2. **Mark**: the file is shown with line numbers. The user selects lines and marks them as **Header (text)** or **Table (CSV / TSV)**.
   Each block has a rule for where it starts and ends, shown as a sentence, chosen from: top of file, fixed line, the line containing a
   given text, the line after it, first empty line, end of file. This is how a table with a moving first line is found in the next file.
   Blocks and rules are saved as a YAML recipe next to the project.
3. **Build** (Nodify canvas): arriving from Mark, the canvas already holds a File node and one container node per marked block, connected.
   Palette: marked blocks, containers (Text, CSV table, TSV table), destinations (.NET object). Each container writes its result as JSON
   to a temp file by itself; the user draws the wire from the container's JSON output to the **.NET object** node. "Test run" on the toolbar;
   bottom tabs: Issues, Serialized JSON, Result object, Run log. "Generate DLL" is enabled only after a passing test run with the current settings.
4. **Wrangle** (opens from a CSV/TSV container): a list of steps applied top to bottom, with a before/after view per step, and **Inputs**
   (named values with test values that the calling application passes in). Wrangling happens BEFORE the JSON is written.

## Output for the POC
- Text container -> `string`.
- CSV / TSV container -> `List<Dictionary<string, string>>` (all values stay text exactly as written, e.g. "4,87").
- The .NET object node deserializes each connected JSON into the configured type; one node, one part per connected container.
- The DLL returns the final object only (not the intermediate JSON). The DLL writes the same temp JSON files as the designer, into a temp
  folder, and deletes them after the run unless the caller asks to keep them.

## Wrangling steps for the POC (everything is chosen in the UI, nothing fixed in code)
1. **Split a column**: one or two levels (e.g. "S-1:A|B" -> part before ":" and a list split on "|"). User names the parts.
2. **Find rows**: conditions "is" / "contains" against a typed value or an Input, joined by AND. With **Expect**: exactly one / at least one /
   any number; a broken expectation stops the run with a plain sentence ("No row found for Sample ID S-...").
3. **Repeating columns to rows**: user selects the columns of one group (any number of columns, e.g. RS1.Name, RS1.Wert, RS1.Einheit);
   every group with the same pattern becomes a row; empty groups left out; a missing column in a group gives empty text.
4. **Rename** and **Choose columns**.

## Reference case (acceptance test of the whole POC)
Synthetic CSV shaped like the owner's example: a column `ID2.Wert` holding `SampleId:Guid|Guid`, and repeating groups `RSn.Name`,
`RSn.Wert`, `RSn.Einheit`. Inputs: Sample ID, Data item ID. Result: a list of {Name, Value, Unit} sets, e.g. Säurezahl / 4,87 / mg KOH/g.
The real file exists only in the owner's protected environment; a local-only test reads its path from the environment variable
`LABFILEREADER_REAL_FILE` and is skipped when the variable is not set (this is the only allowed skip).

## Milestones (one at a time; each ends with its checks passing and the owner writing "accepted" in STATUS.md)
- **M0 Skeleton and harvest.** New solution (app, engine library, tests). Packages restored. Bring over the reusable code listed in
  REUSE_MAP.md with its tests. Check: solution builds with 0 warnings from new code; harvested tests pass; app window opens.
- **M1 File and Mark.** Screens 1 and 2 with manual marking only, the start/end rules, YAML recipe save/load.
  Check: mark header + table on the synthetic file; re-open a second synthetic file where the table starts on another line; blocks found by the rules.
- **M2 Containers to JSON.** Text and CSV/TSV containers read their block with ETLBox and write JSON temp files.
  Check: JSON content equals the expected rows for both synthetic files; originals unchanged (hash before/after).
- **M3 Build canvas.** Nodify canvas with pre-placed nodes, wire to .NET object, Test run, the four bottom tabs.
  Check: test run returns `string` + `List<Dictionary<string,string>>`; Generate DLL stays disabled before a passing run.
- **M4 Wrangle.** Inputs and the steps above with before/after.
  Check: the reference case returns exactly the expected sets; changing an Input to an unknown sample gives the plain "No row found" sentence.
- **M5 Generate DLL.** DLL from the pipeline; small console consumer.
  Check: consumer gets the same list as the designer for the reference case and for a second file with a different number of rows; no licence key in the DLL.

## Out of scope for the POC (always parked)
Auto-detect / "Suggest for me"; XML and JSON containers; destinations other than .NET object (database, REST, text file); number/date typing;
several tables of the same kind in one file; known-instrument matching; dark theme; lineage log; archiving the original file / SQLite /
DAMA-DMBOK features; installer; performance work; more than 5,000 rows (needs an ETLBox licence).

## Later (after the POC is accepted)
The list above, in the owner's order of priority. Do not prepare for them now beyond not blocking them.
