# Status

CURRENT milestone: **M0 Skeleton and harvest**

| Milestone | State | Accepted by owner |
|---|---|---|
| M0 Skeleton and harvest | not started | |
| M1 File and Mark | not started | |
| M2 Containers to JSON | not started | |
| M3 Build canvas | not started | |
| M4 Wrangle | not started | |
| M5 Generate DLL | not started | |

## Log (newest first; Copilot adds an entry after every task: what was done, checks run with real output, what is not done)
