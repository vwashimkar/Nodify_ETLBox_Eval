# Reuse map: what to take from the earlier project

Earlier project: repo `Nodify_ETLBox_Eval` (app `Nodify_ETLBox`, tests `Nodify_ETLBox.Tests`, root namespace `EtlDesigner`, branch `g7`).
It is a **read-only reference**. Never edit it. During M0 it is opened beside this repo so its files can be copied; after M0 it is closed.

The names below come from that project's task reports. **Verify each one exists before copying** (search by class name); if one is missing
or different, say so in STATUS.md instead of guessing. Copy the class with its tests, rename the namespace to `LabFileReader`, then delete
members the POC does not use.

## Bring (needed by a milestone)
| What | Earlier name(s) | For | Notes |
|---|---|---|---|
| Stream that exposes only a line range of a file to ETLBox | `PartStream` | M2 | Originals stay untouched. |
| ETLBox CSV/TSV read of a part | `CsvRecordReader` (part overload, `CsvRecordReader.Part.cs`), `CsvPreviewReader` | M2 | Keep: tab delimiter fix (`"\t"` must stay a tab), delimiter detection OFF for part reads. |
| Running a pipeline and collecting rows / rejects | `PipelineRunner`, `PipelineDefinition` | M3 | Take the smallest part that runs source -> steps -> destination. |
| Split logic for composite values | `ParseValue` step, `ColumnSplit` / `ColumnSplitSettings` | M4 | Basis for "Split a column" (two levels). |
| Plain-language error mapping | `PlainErrorText` (+ tests) | M1 to M5 | Extend with the new sentences. |
| DLL generation with Roslyn from embedded sources | `CsvPipelineDllGenerator`, `GenerateDllViewModel`, the gate that needs a passing run (`PipelineHash`) | M5 | The generator needs the .NET SDK reference pack on the build machine. |
| Console consumer used to test a generated DLL | the consumer project used by `GuidedBuilderDllTests` | M5 | |
| Light theme tokens and base styles | the token resource dictionaries | M1 | Light only for the POC. Colours and type are in docs/design. |
| WPF test host for view-model / window tests on an STA thread | `WpfHost` | M1 to M4 | |
| YAML read/write helpers | the template store's YamlDotNet usage (`ITemplateStore`) | M1 | Only the serialization pattern; the recipe format is new and simpler. |
| Nodify canvas wiring (nodes, connections, connection rules) | `EditorViewModel`, `NodeViewModel`, `MainWindow.xaml` canvas part | M3 | Take the minimum for 3 node kinds; no palette drag rules beyond them. |

## Lessons to keep (already paid for)
- ETLBox free edition stops at about 5,000 rows per source; keep test files small.
- Turn off CSV delimiter auto-detection when the delimiter is known; it misreads small tables.
- A field like `=""` or stray quotes makes the CSV reader fail on the whole part: show the row and line in a plain sentence.
- Column names shown at design time must come from the same reader the run uses.
- Dark theme needs a default text style from tokens; unthemed text turns black. (Dark is out of scope now; do not create the problem.)
- Tests that measure memory or timing must not run in parallel with other tests.
- Keep the laptop awake during long test runs.

## Do not bring
The auto-detector and its truth tests; Intake Studio; the Guided builder window; templates and similarity matching; the CSV part locator
(`CsvPartLocator`, `CsvPartSelector`) since blocks are now found by the Mark rules; validation statuses and confidence words; the legacy
five-node chain (CsvSource, Filter, ToJson, ...) and its `--run-tests` spike; lineage log; all `reports/` and `TASK_*.md` files.

## Design reference
`docs/design/` holds exported images of the four screens (File, Mark, Build, Wrangle). Match layout, wording and colours; the sample data in
the images is placeholder.
